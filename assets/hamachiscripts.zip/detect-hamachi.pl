#!/usr/bin/perl -w

print "\n==========\nHamachi Network Discovery\n==========\n";
print "The names come fomr names.hmc file , modify it if you want\n\n";
$NAME = "names.hmc";
open(NAME) or die("Network names file names.hmc is missing");

foreach $line(<NAME>) {
chomp ($line);
$out =  `hamachi join $line 98098098` ;
if ($out =~/password/){print "Discovered network :".$line."\n";}
}
print "\n\n";


