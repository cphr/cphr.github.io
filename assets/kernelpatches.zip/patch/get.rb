require 'rubygems'
#require 'hpricot'
require 'open-uri'
require 'net/http'  

#get Patches
#https://github.com/evdenis/cvehound/tree/master/cvehound/data


def getPLinks(url)
  patches = Array.new 
  doc = Hpricot(open(url)) # open web page
  doc.search("a[@href]").map { |x| x['href'] }.each do |param| # for every link do     
    param = param.to_s # element to string conversion
    reg = /.*commitdiff.*h=.*/
    if reg.match(param.to_s)
      patches.push("https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/patch/?id="+param.to_s)
    end
  end
  return patches  
end  


#read diff
def getPatch(url)  
    begin      
      
    doc = Hpricot(open(url.to_s)) # open web page
    doc = doc.at('div[@class="patchset"]')
    p doc  
    doc = doc.inner_text
    return doc.to_s
    rescue Exception => e
      sleep 5
      p e.to_s
      return " "
    end
    
end
    
#clear non-printables
class String
  def remove_non_ascii
    require 'iconv'
    Iconv.conv('ASCII//IGNORE', 'UTF8', self)
  end
end

require 'net/http'
require 'down'
#part of base library
line_num=0
text=File.open('patches.txt').read
text.gsub!(/\r\n?/, "\n")
text.each_line do |line|
  line = line[0,line.length-1]
  down =  "https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/patch/?id="+line
  file = Down.download(down)
  FileUtils.mv(file, line+".diff")
  p line 
end
    
